
//hosting API

var express = require('express');
const cors = require("cors");
var app = express();

app.use(cors());

var fundraiserAPI = require("./controller-api/api-controller");

var bodyparser=require("body-parser");

app.use(bodyparser.urlencoded({extended:false}));

app.use("/api/fundraiser", fundraiserAPI); //fundraiser api

app.listen(3060);
console.log("Server up and running on port 3060"); //if connection successful, console retrieve this message
 




